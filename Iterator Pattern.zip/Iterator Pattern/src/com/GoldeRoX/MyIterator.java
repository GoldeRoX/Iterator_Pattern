package com.GoldeRoX;

public interface MyIterator<T> {
    boolean hasNext();
    T next();
}
